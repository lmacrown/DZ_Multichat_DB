--------------------------------------------------------
--  ������ ������ - ������-11��-14-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CLIENT
--------------------------------------------------------

  CREATE TABLE "MULTICHAT"."CLIENT" 
   (	"NO" NUMBER, 
	"USERID" VARCHAR2(20 BYTE), 
	"CHATNAME" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table CLIENT
--------------------------------------------------------

  ALTER TABLE "MULTICHAT"."CLIENT" MODIFY ("NO" NOT NULL ENABLE);
  ALTER TABLE "MULTICHAT"."CLIENT" MODIFY ("USERID" NOT NULL ENABLE);
  ALTER TABLE "MULTICHAT"."CLIENT" MODIFY ("CHATNAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table CLIENT
--------------------------------------------------------

  ALTER TABLE "MULTICHAT"."CLIENT" ADD CONSTRAINT "CLIENT_FK1" FOREIGN KEY ("NO")
	  REFERENCES "MULTICHAT"."CHATTINGROOM" ("NO") ON DELETE CASCADE ENABLE;
  ALTER TABLE "MULTICHAT"."CLIENT" ADD CONSTRAINT "CLIENT_FK2" FOREIGN KEY ("USERID")
	  REFERENCES "MULTICHAT"."MEMBER" ("USERID") ON DELETE CASCADE ENABLE;
